﻿namespace MemberManagement.entity
{
    public class MemberReport
    {
        public int Id { get; set; }
        public int StudentNumber { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string LessonName { get; set; }
        public int Score { get; set; }
        public int Absenteeism { get; set; }
        public string State { get; set; }

    }
}
